package project.backend.domain.chat.chatroom.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class RecentChatRoomResponse {

    private Long roomId;
    private String inviteCode;
}
