package project.backend.domain.chat.chatmessage.dto.git;

public enum GitEventType {
    ISSUE_OPEN, PR_OPEN, PR_MERGED, PR_REVIEW
}
