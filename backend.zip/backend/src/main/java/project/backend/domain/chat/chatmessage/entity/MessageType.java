package project.backend.domain.chat.chatmessage.entity;

public enum MessageType {
    CODE, TEXT, IMAGE, GIT
}
