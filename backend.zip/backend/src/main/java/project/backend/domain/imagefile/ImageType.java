package project.backend.domain.imagefile;

public enum ImageType {
  CHAT_IMAGE,
  PROFILE_IMAGE;
}
